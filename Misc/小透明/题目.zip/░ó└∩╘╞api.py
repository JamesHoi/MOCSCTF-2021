import urllib.request as req
import requests as rq
import json
phone=str(16601296606)
code=str(620403)
host='http://yzxyyyzm.market.alicloudapi.com/yzx/voiceCodeSms'
path = '/yzx/voiceCodeSms'
appcode='253ca677081e46759e479dc603391345'

data={'phone':phone,'variable':'code:'+code}

headers={'Authorization':'APPCODE ' + appcode}
res = rq.post(url=host, data=data, headers=headers)
print(res)
